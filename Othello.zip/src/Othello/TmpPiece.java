package Othello;

class TmpPiece {
    int x, y;
    int state;
    TmpPiece(int x, int y, int state) {
        this.x = x;
        this.y = y;
        this.state = state;
    }
}
